import { createHash, randomBytes, randomUUID, scryptSync, timingSafeEqual } from "node:crypto";
import { FANTASY_CONFIG } from "../js/data/fantasyConfig.js";

const clone = (value) => JSON.parse(JSON.stringify(value));
const text = (value, max = 80) => String(value ?? "").replace(/[<>"`]/g, "").trim().slice(0, max);
const integer = (value, min = 0, max = 1000000) => {
  const number = Number(value);
  if (!Number.isInteger(number) || number < min || number > max) throw new Error("Cantidad inválida.");
  return number;
};

export function createFantasyState() {
  return { schemaVersion: 1, registrationOpen: true, managers: [], freeAgents: [], offers: [], transactions: [], marketWeek: null };
}

export function normalizeFantasyState(value) {
  const defaults = createFantasyState();
  if (!value || typeof value !== "object") return defaults;
  return {
    ...defaults,
    ...value,
    managers: Array.isArray(value.managers) ? value.managers : [],
    freeAgents: Array.isArray(value.freeAgents) ? value.freeAgents : [],
    offers: Array.isArray(value.offers) ? value.offers : [],
    transactions: Array.isArray(value.transactions) ? value.transactions : [],
  };
}

export function fantasyMarketOpen(market, now = new Date()) {
  if (market?.mode === "open") return true;
  if (market?.mode === "closed") return false;
  return new Date(now).getDay() === FANTASY_CONFIG.marketAutoDay;
}

function weekKey(date = new Date()) {
  const value = new Date(date);
  value.setHours(0, 0, 0, 0);
  value.setDate(value.getDate() + 3 - ((value.getDay() + 6) % 7));
  const first = new Date(value.getFullYear(), 0, 4);
  const week = 1 + Math.round(((value - first) / 86400000 - 3 + ((first.getDay() + 6) % 7)) / 7);
  return `${value.getFullYear()}-W${week}`;
}

export function resetFantasyMarketIfNeeded(fantasy, market) {
  if (!fantasyMarketOpen(market)) return false;
  const key = weekKey();
  if (fantasy.marketWeek === key) return false;
  fantasy.marketWeek = key;
  fantasy.managers.forEach((manager) => { manager.clausulazoUsed = false; });
  return true;
}

function pinDigest(pin, salt) {
  return scryptSync(pin, salt, 64).toString("hex");
}

function verifyPin(pin, salt, digest) {
  const expected = Buffer.from(digest, "hex");
  const actual = Buffer.from(pinDigest(pin, salt), "hex");
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

export function managerById(fantasy, id) {
  return fantasy.managers.find((manager) => manager.id === id) || null;
}

export function publicManager(manager) {
  if (!manager) return null;
  const { pinHash, pinSalt, ...publicData } = manager;
  return publicData;
}

export function publicFantasy(fantasy, leagueState, marketOpen) {
  const players = leagueState.players || [];
  const teams = leagueState.teams || [];
  const realPlayers = players.map((player) => ({ ...player, kind: "real", fantasyId: player.id }));
  const freePlayers = fantasy.freeAgents.filter((player) => !player.deleted).map((player) => ({ ...player, kind: "free", fantasyId: player.id }));
  const allPlayers = [...realPlayers, ...freePlayers];
  const standings = fantasy.managers.map((manager) => {
    const score = getManagerScores(manager, fantasy, leagueState);
    const goals = manager.roster.reduce((sum, entry) => {
      if (!entry.playerId.startsWith("p-")) return sum;
      return sum + goalsForPlayer(entry.playerId, leagueState.matches, manager.joinedAt);
    }, 0);
    return { ...publicManager(manager), points: score.total, goals, rounds: score.rounds };
  }).sort((a, b) => b.points - a.points || b.goals - a.goals || a.name.localeCompare(b.name));

  return {
    config: FANTASY_CONFIG,
    registrationOpen: fantasy.registrationOpen,
    marketOpen,
    managers: standings,
    freeAgents: freePlayers,
    players: allPlayers.map(({ pinHash, pinSalt, manualPoints, ...player }) => {
      const realTeam = player.teamId ? teams.find((team) => team.id === player.teamId) : null;
      const isEliminated = realTeam ? realTeamIsEliminated(realTeam.id, leagueState) : false;
      return {
        id: player.fantasyId,
        name: player.name,
        position: player.position,
        value: player.value,
        kind: player.kind,
        realTeamId: player.teamId || null,
        realTeamName: realTeam?.name || "Agente libre",
        isInsignia: Boolean(player.isInsignia && !isEliminated),
        available: player.kind === "free" || !player.isInsignia || isEliminated,
        manualPoints,
      };
    }),
    offers: fantasy.offers.map((offer) => ({
      id: offer.id,
      buyerManagerId: offer.buyerManagerId,
      sellerManagerId: offer.sellerManagerId,
      targetPlayerId: offer.targetPlayerId,
      offeredPlayerId: offer.offeredPlayerId || null,
      cash: offer.cash,
      status: offer.status,
      createdAt: offer.createdAt,
    })),
    transactions: fantasy.transactions.slice(0, 100),
  };
}

function availablePlayer(fantasy, leagueState, playerId) {
  const real = (leagueState.players || []).find((player) => player.id === playerId);
  if (real) {
    if (real.isInsignia && !realTeamIsEliminated(real.teamId, leagueState)) throw new Error("El jugador insignia está protegido hasta que su equipo quede eliminado.");
    return { id: real.id, name: real.name, position: real.position, teamId: real.teamId, value: real.value, kind: "real" };
  }
  const free = fantasy.freeAgents.find((player) => player.id === playerId && !player.deleted);
  if (free) return { id: free.id, name: free.name, position: free.position, teamId: null, value: free.value, kind: "free" };
  throw new Error("El jugador ya no está disponible.");
}

function realTeamIsEliminated(teamId, leagueState) {
  const team = (leagueState.teams || []).find((item) => item.id === teamId);
  if (team?.status === "eliminated") return true;
  return (leagueState.matches || []).some((match) => {
    if (match.phase !== "semifinals" || match.status !== "finished") return false;
    if (match.homeTeamId !== teamId && match.awayTeamId !== teamId) return false;
    if (Number(match.homeScore) === Number(match.awayScore)) return false;
    return match.homeTeamId === teamId ? Number(match.homeScore) < Number(match.awayScore) : Number(match.awayScore) < Number(match.homeScore);
  });
}

function validateRoster(managerId, roster, fantasy, leagueState, options = {}) {
  if (!Array.isArray(roster) || roster.length > FANTASY_CONFIG.rosterSize || (!options.allowIncomplete && roster.length !== FANTASY_CONFIG.rosterSize)) {
    throw new Error(`El equipo debe tener ${FANTASY_CONFIG.rosterSize} jugadores.`);
  }
  const ids = roster.map((entry) => entry.playerId);
  if (new Set(ids).size !== ids.length) throw new Error("No puedes repetir jugadores.");
  const allowedExclusiveIds = new Set(options.allowedExclusiveIds || []);
  const occupied = fantasy.managers.filter((manager) => manager.id !== managerId).flatMap((manager) => manager.roster.map((entry) => entry.playerId)).filter((playerId) => !allowedExclusiveIds.has(playerId));
  if (ids.some((id) => occupied.includes(id))) throw new Error("Ese jugador ya pertenece a otro equipo Fantasy.");

  const positions = new Map();
  const realTeams = new Map();
  let total = 0;
  const resolved = roster.map((entry) => {
    const player = availablePlayer(fantasy, leagueState, entry.playerId);
    const price = integer(entry.price, 0, FANTASY_CONFIG.budget);
    total += price;
    positions.set(player.position, (positions.get(player.position) || 0) + 1);
    if (player.teamId) realTeams.set(player.teamId, (realTeams.get(player.teamId) || 0) + 1);
    return { playerId: player.id, price, kind: player.kind, position: player.position, realTeamId: player.teamId || null };
  });
  if (total > FANTASY_CONFIG.budget || (!options.allowIncomplete && total !== FANTASY_CONFIG.budget)) throw new Error("Debes invertir exactamente 200M en los cinco jugadores.");
  if (roster.length > 0 && !(positions.get("POR") >= 1)) throw new Error("Tu equipo necesita al menos un portero.");
  if ([...positions.values()].some((count) => count > FANTASY_CONFIG.limits.maxPlayersPerPosition)) throw new Error("Máximo dos jugadores por posición.");
  if ([...realTeams.values()].some((count) => count > FANTASY_CONFIG.limits.maxPlayersPerRealTeam)) throw new Error("Máximo dos jugadores del mismo equipo real.");
  return resolved;
}

function completedMatchesByRound(leagueState) {
  const matchdays = [...new Set((leagueState.matches || []).filter((match) => match.homeTeamId && match.awayTeamId).map((match) => Number(match.matchday)).filter(Number.isFinite))];
  return matchdays.filter((matchday) => {
    const matches = leagueState.matches.filter((match) => Number(match.matchday) === matchday && match.homeTeamId && match.awayTeamId);
    return matches.length > 0 && matches.every((match) => match.status === "finished");
  });
}

function joinedAtFilter(match, joinedAt) {
  if (!joinedAt) return true;
  const matchTime = new Date(`${match.date || "1970-01-01"}T${match.time || "00:00"}`).getTime();
  return !Number.isFinite(matchTime) || matchTime >= new Date(joinedAt).getTime();
}

function playerStatsForRound(playerId, manualPoints, matchday, leagueState, joinedAt, fantasyRealTeamId = null, fantasyPosition = null, freeAgent = null) {
  const real = leagueState.players.find((player) => player.id === playerId);
  if (!real && !freeAgent) return { points: Number(manualPoints?.[matchday]) || 0, goals: 0 };
  const realTeamId = fantasyRealTeamId || real?.teamId || null;
  const scoringPosition = fantasyPosition || real?.position || freeAgent?.position;
  const matches = (leagueState.matches || []).filter((match) => Number(match.matchday) === Number(matchday) && match.status === "finished");
  let points = 0;
  let goals = 0;
  let appearances = 0;
  for (const match of matches) {
    const freeScorers = (match.scorers || []).filter((event) => event.playerId === playerId && !real);
    const freeBookings = (match.bookings || []).filter((event) => event.playerId === playerId && !real);
    const eventTeamId = freeScorers[0]?.teamId || freeBookings[0]?.teamId;
    const teamId = realTeamId || eventTeamId;
    const hasAppearance = real
      ? teamId === match.homeTeamId || teamId === match.awayTeamId
      : freeScorers.length > 0 || freeBookings.length > 0;
    if (!hasAppearance || (teamId !== match.homeTeamId && teamId !== match.awayTeamId)) continue;
    appearances += 1;
    const ownScore = teamId === match.homeTeamId ? Number(match.homeScore) : Number(match.awayScore);
    const rivalScore = teamId === match.homeTeamId ? Number(match.awayScore) : Number(match.homeScore);
    points += ownScore > rivalScore ? FANTASY_CONFIG.points.win : ownScore === rivalScore ? FANTASY_CONFIG.points.draw : FANTASY_CONFIG.points.loss;
    const conceded = teamId === match.homeTeamId ? Number(match.awayScore) : Number(match.homeScore);
    if (["POR", "DEF"].includes(scoringPosition) && conceded === 0) points += FANTASY_CONFIG.points.cleanSheet;
    for (const scorer of match.scorers || []) {
      if (scorer.playerId !== playerId) continue;
      const count = scorer.type === "doble" ? 2 : 1;
      goals += count;
      points += count * (FANTASY_CONFIG.points.goal[scoringPosition] || 0);
    }
    for (const booking of match.bookings || []) {
      if (booking.playerId === playerId) points += booking.card === "red" ? FANTASY_CONFIG.points.redCard : FANTASY_CONFIG.points.yellowCard;
    }
  }
  if (freeAgent && appearances === 0) points = Number(manualPoints?.[matchday]) || 0;
  return { points, goals };
}

function goalsForPlayer(playerId, matches, joinedAt) {
  return matches.filter((match) => match.status === "finished").flatMap((match) => match.scorers || []).filter((scorer) => scorer.playerId === playerId).reduce((sum, scorer) => sum + (scorer.type === "doble" ? 2 : 1), 0);
}

export function getManagerScores(manager, fantasy, leagueState) {
  const rounds = [...new Set((leagueState.matches || []).map((match) => Number(match.matchday)).filter(Number.isFinite))].sort((a, b) => a - b).map((matchday) => {
    let points = 0;
    let goals = 0;
    const roundSnapshot = manager.roundRosters?.[matchday];
    const roundRoster = roundSnapshot?.roster || manager.roster;
    const roundCaptainId = roundSnapshot?.captainId || manager.captainId;
    const details = roundRoster.map((entry) => {
      const freeAgent = fantasy.freeAgents.find((item) => item.id === entry.playerId);
      const stats = playerStatsForRound(entry.playerId, freeAgent?.manualPoints || entry.manualPoints, matchday, leagueState, manager.joinedAt, entry.realTeamId, entry.position, freeAgent);
      const multiplier = entry.playerId === roundCaptainId ? FANTASY_CONFIG.points.captainMultiplier : 1;
      const total = stats.points * multiplier;
      points += total;
      goals += stats.goals;
      const player = (leagueState.players || []).find((item) => item.id === entry.playerId) || fantasy.freeAgents.find((item) => item.id === entry.playerId);
      return { playerId: entry.playerId, name: player?.name || "Jugador", points: total, goals: stats.goals, captain: multiplier > 1 };
    });
    return { matchday, points, goals, details };
  });
  return { total: rounds.reduce((sum, round) => sum + round.points, 0), rounds };
}

export function recalculateFantasyPayouts(fantasy, leagueState, { creditNewSnapshots = true } = {}) {
  const closedRounds = new Set(completedMatchesByRound(leagueState));
  for (const manager of fantasy.managers) {
    manager.paidPointsByRound ||= {};
    manager.roundRosters ||= {};
    for (const round of closedRounds) {
      if (!manager.roundRosters[round]) {
        if (manager.roster.length) {
          manager.roundRosters[round] = { roster: clone(manager.roster), captainId: manager.captainId };
        }
      }
      if (!manager.roundRosters[round]) continue;
      const detail = getManagerScores(manager, fantasy, leagueState).rounds.find((item) => item.matchday === round);
      const creditedPoints = Math.max(0, detail?.points || 0);
      const previous = Number(manager.paidPointsByRound[round]) || 0;
      if (!creditNewSnapshots && !Object.hasOwn(manager.paidPointsByRound, round)) {
        manager.paidPointsByRound[round] = creditedPoints;
        continue;
      }
      if (creditedPoints !== previous) {
        manager.cash = Math.max(0, manager.cash + (creditedPoints - previous) * FANTASY_CONFIG.cashPerPoint);
        manager.paidPointsByRound[round] = creditedPoints;
      }
    }
  }
}

function assertFantasyRole(requestSession) {
  if (requestSession && ["ADMIN", "PRESIDENT", "PLAYER"].includes(requestSession.role)) {
    throw new Error("Los presidentes y jugadores reales no pueden participar en Fantasy.");
  }
}

export function registerManager(fantasy, leagueState, { name, pin, appSession }) {
  assertFantasyRole(appSession);
  if (!fantasy.registrationOpen) throw new Error("Las inscripciones Fantasy están cerradas.");
  const managerName = text(name, FANTASY_CONFIG.limits.managerNameLength);
  if (managerName.length < 2) throw new Error("El nombre del manager debe tener al menos 2 caracteres.");
  if (!/^\d{4}$/.test(String(pin || ""))) throw new Error("El PIN debe tener exactamente 4 dígitos.");
  if (fantasy.managers.some((manager) => manager.name.toLocaleLowerCase() === managerName.toLocaleLowerCase())) throw new Error("Ese nombre de manager ya está registrado.");
  const salt = randomBytes(16).toString("hex");
  const manager = {
    id: `fm-${randomUUID()}`,
    name: managerName,
    pinSalt: salt,
    pinHash: pinDigest(pin, salt),
    joinedAt: new Date().toISOString(),
    roster: [], captainId: null, cash: 0, clausulazoUsed: false, paidPointsByRound: {}, roundRosters: {},
  };
  fantasy.managers.push(manager);
  return manager;
}

export function loginManager(fantasy, { name, pin }) {
  const managerName = text(name, FANTASY_CONFIG.limits.managerNameLength).toLocaleLowerCase();
  const manager = fantasy.managers.find((item) => item.name.toLocaleLowerCase() === managerName);
  if (!manager || !verifyPin(String(pin || ""), manager.pinSalt, manager.pinHash)) throw new Error("Nombre de manager o PIN incorrectos.");
  return manager;
}

export function setManagerRoster(fantasy, leagueState, manager, roster, captainId) {
  if (!Array.isArray(roster) || roster.length !== FANTASY_CONFIG.rosterSize) throw new Error("Selecciona exactamente cinco jugadores.");
  if (roster.some((entry) => fantasy.freeAgents.some((agent) => agent.id === entry.playerId))) throw new Error("Los agentes libres se fichan desde el mercado y se pagan con tu caja.");
  const validated = validateRoster(manager.id, roster, fantasy, leagueState);
  if (!validated.some((entry) => entry.playerId === captainId)) throw new Error("El capitán debe pertenecer a tu equipo.");
  manager.roster = validated;
  manager.captainId = captainId;
  recalculateFantasyPayouts(fantasy, leagueState, { creditNewSnapshots: false });
  return manager;
}

function assertCanReceive(manager, incoming, outgoingPlayerId = null, fantasy, leagueState, allowedExclusiveIds = []) {
  const current = manager.roster.filter((entry) => entry.playerId !== outgoingPlayerId);
  if (current.some((entry) => entry.playerId === incoming.playerId)) throw new Error("Ese jugador ya está en tu plantilla.");
  validateRoster(manager.id, [...current, incoming], fantasy, leagueState, { allowIncomplete: true, allowedExclusiveIds });
}

export function addFreeAgent(fantasy, leagueState, data) {
  const name = text(data.name, 60);
  const position = String(data.position || "");
  if (name.length < 2 || !["POR", "DEF", "MED", "DEL"].includes(position)) throw new Error("Nombre o posición de agente libre inválidos.");
  const value = integer(data.value, 1, FANTASY_CONFIG.budget);
  const agent = { id: `fa-${randomUUID()}`, name, position, value, manualPoints: {}, createdAt: new Date().toISOString() };
  fantasy.freeAgents.push(agent);
  return agent;
}

export function editFreeAgent(fantasy, leagueState, data) {
  const agent = fantasy.freeAgents.find((item) => item.id === data.id);
  if (!agent) throw new Error("Agente libre no encontrado.");
  const previous = { name: agent.name, position: agent.position, value: agent.value };
  agent.name = text(data.name, 60);
  if (!["POR", "DEF", "MED", "DEL"].includes(data.position)) throw new Error("Posición inválida.");
  agent.position = data.position;
  agent.value = integer(data.value, 1, FANTASY_CONFIG.budget);
  try {
    for (const manager of fantasy.managers) {
      if (manager.roster.some((entry) => entry.playerId === agent.id)) {
        validateRoster(manager.id, manager.roster, fantasy, leagueState, { allowIncomplete: false });
      }
    }
  } catch (error) {
    Object.assign(agent, previous);
    throw error;
  }
  return agent;
}

export function deleteFreeAgent(fantasy, agentId) {
  const agent = fantasy.freeAgents.find((item) => item.id === agentId);
  if (!agent) throw new Error("Agente libre no encontrado.");
  if (fantasy.managers.some((manager) => manager.roster.some((entry) => entry.playerId === agentId))) throw new Error("No se puede borrar un agente libre que está en un equipo Fantasy.");
  fantasy.freeAgents = fantasy.freeAgents.filter((item) => item.id !== agentId);
}

export function buyFreeAgent(fantasy, leagueState, manager, agentId, replacePlayerId = null) {
  const agent = availablePlayer(fantasy, leagueState, agentId);
  if (agent.kind !== "free") throw new Error("Solo puedes comprar agentes libres en esta operación.");
  if (manager.roster.some((item) => item.playerId === agent.id)) throw new Error("Ese agente ya está en tu plantilla.");
  if (manager.cash < agent.value) throw new Error("No tienes caja suficiente.");
  if (replacePlayerId && !manager.roster.some((entry) => entry.playerId === replacePlayerId)) throw new Error("El jugador elegido para reemplazo no pertenece a tu equipo.");
  if (manager.roster.length >= FANTASY_CONFIG.rosterSize) {
    if (!replacePlayerId || !manager.roster.some((entry) => entry.playerId === replacePlayerId)) throw new Error("Elige qué jugador liberar para fichar al agente libre.");
  }
    const oldRoster = manager.roster;
    const previousRoster = oldRoster.filter((entry) => entry.playerId !== replacePlayerId);
  const entry = { playerId: agent.id, price: agent.value, kind: "free", position: agent.position, manualPoints: {} };
  manager.roster = previousRoster;
  try { assertCanReceive(manager, entry, null, fantasy, leagueState); }
    catch (error) { manager.roster = oldRoster; throw error; }
  manager.cash -= agent.value;
  if (replacePlayerId === manager.captainId) manager.captainId = null;
  manager.roster.push(entry);
  return manager;
}

export function releaseManagerPlayer(manager, playerId) {
  const index = manager.roster.findIndex((entry) => entry.playerId === playerId);
  if (index < 0) throw new Error("Ese jugador no está en tu equipo Fantasy.");
  const released = manager.roster[index];
  const nextRoster = manager.roster.filter((entry) => entry.playerId !== playerId);
  if (released.kind !== "free" && released.position === "POR" && nextRoster.length > 0 && !nextRoster.some((entry) => entry.position === "POR")) {
    throw new Error("No puedes liberar tu último portero.");
  }
  manager.roster = nextRoster;
  if (manager.captainId === playerId) manager.captainId = null;
  return manager;
}

export function setFreeAgentManualPoints(fantasy, data) {
  const agent = fantasy.freeAgents.find((item) => item.id === data.playerId);
  if (!agent) throw new Error("Agente libre no encontrado.");
  const matchday = integer(data.matchday, 1, 1000);
  const points = integer(data.points, -1000, 1000);
  agent.manualPoints[matchday] = points;
}

export function createTransferOffer(fantasy, leagueState, buyer, data, market) {
  if (!fantasyMarketOpen(market)) throw new Error("El mercado Fantasy está cerrado.");
  const seller = managerById(fantasy, data.sellerManagerId);
  if (!seller || seller.id === buyer.id) throw new Error("Manager vendedor inválido.");
  const targetPlayerId = text(data.targetPlayerId, 80);
  const target = seller.roster.find((entry) => entry.playerId === targetPlayerId);
  if (!target) throw new Error("El jugador objetivo ya no pertenece al vendedor.");
  availablePlayer(fantasy, leagueState, targetPlayerId);
  const offeredPlayerId = data.offeredPlayerId ? text(data.offeredPlayerId, 80) : null;
  if (offeredPlayerId && !buyer.roster.some((entry) => entry.playerId === offeredPlayerId)) throw new Error("El jugador ofrecido no pertenece a tu equipo.");
  if (offeredPlayerId) availablePlayer(fantasy, leagueState, offeredPlayerId);
  const cash = integer(data.cash || 0, 0, 1000000);
  if (!cash && !offeredPlayerId) throw new Error("Ofrece dinero, un jugador o ambas cosas.");
  if (buyer.cash < cash) throw new Error("No tienes caja suficiente para esa oferta.");
  if (buyer.roster.length - (offeredPlayerId ? 1 : 0) >= FANTASY_CONFIG.rosterSize) throw new Error("Tu equipo no tiene espacio para ese jugador.");
  if (offeredPlayerId) {
    const offered = buyer.roster.find((entry) => entry.playerId === offeredPlayerId);
    if (target.position === "POR" && !seller.roster.some((entry) => entry.playerId !== targetPlayerId && entry.position === "POR") && offered.position !== "POR") throw new Error("El vendedor no puede quedarse sin portero.");
    assertCanReceive(seller, offered, targetPlayerId, fantasy, leagueState, [offered.playerId]);
  } else {
    if (target.position === "POR" && !seller.roster.some((entry) => entry.playerId !== targetPlayerId && entry.position === "POR")) throw new Error("El vendedor no puede quedarse sin portero.");
    assertCanReceive(buyer, target, null, fantasy, leagueState, [target.playerId]);
  }
  const offer = { id: `fo-${randomUUID()}`, buyerManagerId: buyer.id, sellerManagerId: seller.id, targetPlayerId, offeredPlayerId, cash, status: "pending", createdAt: new Date().toISOString() };
  fantasy.offers.unshift(offer);
  return offer;
}

export function respondTransferOffer(fantasy, leagueState, seller, offerId, accept) {
  const offer = fantasy.offers.find((item) => item.id === offerId && item.status === "pending");
  if (!offer || offer.sellerManagerId !== seller.id) throw new Error("La oferta ya no está disponible para este manager.");
  const buyer = managerById(fantasy, offer.buyerManagerId);
  if (!buyer) throw new Error("Manager comprador no encontrado.");
  if (!accept) { offer.status = "rejected"; return offer; }
  if (!fantasyMarketOpen(leagueState.market)) throw new Error("El mercado Fantasy está cerrado.");
  const targetIndex = seller.roster.findIndex((entry) => entry.playerId === offer.targetPlayerId);
  if (targetIndex < 0) throw new Error("El jugador objetivo ya no está en tu equipo.");
  const target = seller.roster[targetIndex];
  const targetDetails = availablePlayer(fantasy, leagueState, target.playerId);
  const offeredIndex = offer.offeredPlayerId ? buyer.roster.findIndex((entry) => entry.playerId === offer.offeredPlayerId) : -1;
  if (offer.offeredPlayerId && offeredIndex < 0) throw new Error("El jugador ofrecido ya no está en el equipo comprador.");
  if (buyer.cash < offer.cash) throw new Error("El comprador ya no tiene caja suficiente.");
  if (offeredIndex >= 0) {
    const offered = buyer.roster[offeredIndex];
    const offeredDetails = availablePlayer(fantasy, leagueState, offered.playerId);
    const sellerRosterAfter = seller.roster.filter((entry) => entry.playerId !== target.playerId).concat(offered);
    const buyerRosterAfter = buyer.roster.filter((entry) => entry.playerId !== offered.playerId).concat(target);
    validateRoster(seller.id, sellerRosterAfter, fantasy, leagueState, { allowIncomplete: true, allowedExclusiveIds: [offered.playerId] });
    validateRoster(buyer.id, buyerRosterAfter, fantasy, leagueState, { allowIncomplete: true, allowedExclusiveIds: [target.playerId] });
    assertCanReceive(seller, offered, target.playerId, fantasy, leagueState, [offered.playerId]);
    assertCanReceive(buyer, target, offered.playerId, fantasy, leagueState, [target.playerId]);
    seller.roster.splice(targetIndex, 1, offered);
    buyer.roster.splice(offeredIndex, 1, target);
    offered.realTeamId = offeredDetails.teamId || null;
    offered.position = offeredDetails.position;
    target.realTeamId = targetDetails.teamId || null;
    target.position = targetDetails.position;
    if (seller.captainId === target.playerId) seller.captainId = offered.playerId;
    if (buyer.captainId === offered.playerId) buyer.captainId = target.playerId;
  } else {
    if (buyer.roster.length >= FANTASY_CONFIG.rosterSize) throw new Error("El comprador no tiene una plaza libre.");
    if (target.position === "POR" && !seller.roster.some((entry) => entry.playerId !== target.playerId && entry.position === "POR")) throw new Error("El vendedor no puede quedarse sin portero.");
    assertCanReceive(buyer, target, null, fantasy, leagueState, [target.playerId]);
    seller.roster.splice(targetIndex, 1);
    buyer.roster.push(target);
    target.realTeamId = targetDetails.teamId || null;
    target.position = targetDetails.position;
    if (seller.captainId === target.playerId) seller.captainId = null;
  }
  buyer.cash -= offer.cash;
  seller.cash += offer.cash;
  offer.status = "accepted";
  return offer;
}

export function executeFantasyClausulazo(fantasy, leagueState, buyer, targetManagerId, playerId, replacePlayerId = null) {
  if (!fantasyMarketOpen(leagueState.market)) throw new Error("El mercado Fantasy está cerrado.");
  resetFantasyMarketIfNeeded(fantasy, leagueState.market);
  if (buyer.clausulazoUsed) throw new Error("Ya utilizaste tu clausulazo Fantasy esta semana.");
  const seller = managerById(fantasy, targetManagerId);
  if (!seller || seller.id === buyer.id) throw new Error("Manager vendedor inválido.");
  const index = seller.roster.findIndex((entry) => entry.playerId === playerId);
  if (index < 0) throw new Error("Ese jugador ya no pertenece al manager.");
  const entry = seller.roster[index];
  const player = availablePlayer(fantasy, leagueState, entry.playerId);
  if (entry.position === "POR" && !seller.roster.some((item) => item.playerId !== playerId && item.position === "POR")) throw new Error("No puedes clausular el último portero del manager.");
  const price = integer(entry.price, 0, FANTASY_CONFIG.budget);
  if (buyer.cash < price) throw new Error("No tienes caja suficiente para el clausulazo.");
  if (buyer.roster.length >= FANTASY_CONFIG.rosterSize && (!replacePlayerId || !buyer.roster.some((item) => item.playerId === replacePlayerId))) throw new Error("Elige qué jugador liberar para ejecutar el clausulazo.");
  if (replacePlayerId && !buyer.roster.some((item) => item.playerId === replacePlayerId)) throw new Error("El jugador elegido para reemplazo no pertenece a tu equipo.");
  if (replacePlayerId === playerId) throw new Error("No puedes liberar al jugador objetivo.");
  const dropIndex = replacePlayerId ? buyer.roster.findIndex((item) => item.playerId === replacePlayerId) : -1;
  const droppedEntry = dropIndex >= 0 ? buyer.roster.splice(dropIndex, 1)[0] : null;
  try { assertCanReceive(buyer, entry, null, fantasy, leagueState, [entry.playerId]); }
  catch (error) { if (droppedEntry) buyer.roster.splice(dropIndex, 0, droppedEntry); throw error; }
  seller.roster.splice(index, 1);
  entry.realTeamId = player.teamId || null;
  entry.position = player.position;
  buyer.roster.push(entry);
  if (seller.captainId === playerId) seller.captainId = null;
  if (buyer.captainId === replacePlayerId) buyer.captainId = null;
  buyer.cash -= price;
  seller.cash += price;
  buyer.clausulazoUsed = true;
  fantasy.transactions.unshift({ type: "clausulazo", buyerManagerId: buyer.id, sellerManagerId: seller.id, playerId, playerName: player.name, price, at: new Date().toISOString() });
  return buyer;
}

export function resetManagerFantasy(fantasy, managerId) {
  const manager = managerById(fantasy, managerId);
  if (!manager) throw new Error("Manager no encontrado.");
  manager.roster = [];
  manager.captainId = null;
  manager.cash = 0;
  manager.clausulazoUsed = false;
  manager.paidPointsByRound = {};
  manager.roundRosters = {};
  fantasy.offers = fantasy.offers.filter((offer) => offer.buyerManagerId !== managerId && offer.sellerManagerId !== managerId);
}

export function resetAllFantasy() {
  return createFantasyState();
}

export function setFantasyRegistration(fantasy, isOpen) {
  fantasy.registrationOpen = Boolean(isOpen);
}

export function createFantasySessionToken() {
  return randomUUID();
}

export function sanitizeManager(manager) {
  return publicManager(manager);
}
