import test from "node:test";
import assert from "node:assert/strict";
import {
  createFantasyState,
  fantasyMarketOpen,
  getManagerScores,
  recalculateFantasyPayouts,
  registerManager,
  setManagerRoster,
  createTransferOffer,
  respondTransferOffer,
  executeFantasyClausulazo,
  addFreeAgent,
  buyFreeAgent,
} from "../server/fantasy.js";

const kickoff = new Date(Date.now() + 60_000).toISOString();
const date = kickoff.slice(0, 10);
const time = kickoff.slice(11, 16);

function fixture() {
  const fantasy = createFantasyState();
  const league = {
    market: { mode: "open" },
    teams: [
      { id: "a", name: "A", status: "active" },
      { id: "b", name: "B", status: "active" },
      { id: "c", name: "C", status: "active" },
      { id: "d", name: "D", status: "active" },
      { id: "e", name: "E", status: "active" },
    ],
    players: [
      { id: "p1", name: "Portero A", position: "POR", teamId: "a", isInsignia: false },
      { id: "p2", name: "Defensa A", position: "DEF", teamId: "a", isInsignia: false },
      { id: "p3", name: "Portero B", position: "POR", teamId: "b", isInsignia: false },
      { id: "p4", name: "Defensa B", position: "DEF", teamId: "b", isInsignia: false },
      { id: "p5", name: "Medio C", position: "MED", teamId: "c", isInsignia: false },
      { id: "p6", name: "Insignia C", position: "DEL", teamId: "c", isInsignia: true },
      { id: "p7", name: "Delantero B", position: "DEL", teamId: "b", isInsignia: false },
      { id: "p8", name: "Portero D", position: "POR", teamId: "d", isInsignia: false },
      { id: "p9", name: "Defensa D", position: "DEF", teamId: "d", isInsignia: false },
      { id: "p10", name: "Medio E", position: "MED", teamId: "e", isInsignia: false },
      { id: "p11", name: "Delantero E", position: "DEL", teamId: "e", isInsignia: false },
      { id: "p12", name: "Medio B", position: "MED", teamId: "b", isInsignia: false },
    ],
    matches: [{ id: "m1", phase: "groups", matchday: 1, status: "finished", homeTeamId: "a", awayTeamId: "b", homeScore: 2, awayScore: 0, date, time, scorers: [{ playerId: "p1", type: "regular" }], bookings: [{ playerId: "p2", card: "yellow" }] }],
  };
  const a = registerManager(fantasy, league, { name: "Manager A", pin: "1234" });
  a.joinedAt = new Date(Date.now() - 120_000).toISOString();
  const b = registerManager(fantasy, league, { name: "Manager B", pin: "4321" });
  b.joinedAt = a.joinedAt;
  const rosterA = ["p1", "p2", "p3", "p4", "p5"].map((playerId) => ({ playerId, price: 40 }));
  const rosterB = ["p8", "p9", "p10", "p11", "p12"].map((playerId) => ({ playerId, price: 40 }));
  return { fantasy, league, a, b, rosterA, rosterB };
}

test("roster validates five players, exactly 200M, keeper and limits", () => {
  const { fantasy, league, a, rosterA } = fixture();
  assert.equal(setManagerRoster(fantasy, league, a, rosterA, "p1").roster.length, 5);
  assert.throws(() => setManagerRoster(fantasy, league, a, rosterA.map((entry) => ({ ...entry, price: 39 })), "p1"), /exactamente 200M/);
  const insigniaRoster = ["p1", "p2", "p3", "p4", "p6"].map((playerId) => ({ playerId, price: 40 }));
  assert.throws(() => setManagerRoster(fantasy, league, a, insigniaRoster, "p1"), /insignia/);
});

test("a fantasy player is exclusive to one manager", () => {
  const { fantasy, league, a, b, rosterA, rosterB } = fixture();
  setManagerRoster(fantasy, league, a, rosterA, "p1");
  assert.throws(() => setManagerRoster(fantasy, league, b, [{ ...rosterB[0], playerId: "p1" }, ...rosterB.slice(1)], "p1"), /otro equipo Fantasy/);
});

test("late manager sees historical points but starts with zero cash", () => {
  const { fantasy, league, a, rosterA } = fixture();
  setManagerRoster(fantasy, league, a, rosterA, "p1");
  assert.equal(getManagerScores(a, fantasy, league).rounds[0].points, 40);
  assert.equal(a.cash, 0);
});

test("real club players and presidents cannot register as fantasy managers", () => {
  const fantasy = createFantasyState();
  assert.throws(() => registerManager(fantasy, { players: [], teams: [] }, { name: "President", pin: "1234", appSession: { role: "PRESIDENT" } }), /no pueden participar/);
  assert.throws(() => registerManager(fantasy, { players: [], teams: [] }, { name: "Jugador", pin: "1234", appSession: { role: "PLAYER" } }), /no pueden participar/);
});

test("match points include captain multiplier and are paid; result edits recalculate", () => {
  const { fantasy, league, a, rosterA } = fixture();
  league.matches[0].status = "scheduled";
  setManagerRoster(fantasy, league, a, rosterA, "p1");
  assert.equal(a.cash, 0);
  league.matches[0].status = "finished";
  recalculateFantasyPayouts(fantasy, league);
  const score = getManagerScores(a, fantasy, league).rounds[0].points;
  assert.equal(score, 40);
  assert.equal(a.cash, 40);
  league.matches[0].homeScore = 0;
  league.matches[0].awayScore = 1;
  recalculateFantasyPayouts(fantasy, league);
  assert.equal(a.cash, 33);
});

test("negative fantasy round points never reduce cash", () => {
  const { fantasy, league, a } = fixture();
  fantasy.freeAgents = ["POR", "DEF", "MED", "DEL", "DEL"].map((position, index) => ({ id: `fa${index}`, name: `Agente ${index}`, position, manualPoints: { 1: -2 } }));
  a.roster = fantasy.freeAgents.map((agent) => ({ playerId: agent.id, price: 40, kind: "free", position: agent.position }));
  a.captainId = "fa0";
  recalculateFantasyPayouts(fantasy, league);
  assert.equal(getManagerScores(a, fantasy, league).rounds[0].points, -12);
  assert.equal(a.cash, 0);
});

test("free agent appearances score automatically from real match events", () => {
  const { fantasy, league, a } = fixture();
  const agent = { id: "fa-match", name: "Agente DEF", position: "DEF", teamId: null, manualPoints: {} };
  fantasy.freeAgents.push(agent);
  a.roster = [{ playerId: agent.id, price: 200, kind: "free", position: "DEF", manualPoints: {} }];
  a.captainId = agent.id;
  league.matches[0].scorers.push({ playerId: agent.id, teamId: "a", type: "regular" });
  const points = getManagerScores(a, fantasy, league).rounds[0].points;
  assert.equal(points, 26);
});

test("fantasy market honors the shared override", () => {
  assert.equal(fantasyMarketOpen({ mode: "closed" }), false);
  assert.equal(fantasyMarketOpen({ mode: "open" }), true);
  assert.equal(fantasyMarketOpen({ mode: "auto" }, "2026-10-06T12:00:00"), false);
  assert.equal(fantasyMarketOpen({ mode: "auto" }, "2026-10-07T12:00:00"), true);
});

test("free agents can be bought while market is closed using fantasy cash", () => {
  const { fantasy, league, a, rosterA } = fixture();
  setManagerRoster(fantasy, league, a, rosterA, "p1");
  league.market.mode = "closed";
  a.cash = 50;
  const agent = addFreeAgent(fantasy, league, { name: "Agente Test", position: "DEL", value: 15 });
  buyFreeAgent(fantasy, league, a, agent.id, "p5");
  assert.equal(a.cash, 35);
  assert.equal(a.roster.length, 5);
  assert.equal(a.roster.some((entry) => entry.playerId === agent.id), true);
  assert.equal(a.roster.some((entry) => entry.playerId === "p5"), false);
});

test("offer acceptance transfers players and cash; insignia clausulazo is rejected", () => {
  const { fantasy, league, a, b, rosterA, rosterB } = fixture();
  setManagerRoster(fantasy, league, a, rosterA, "p1");
  setManagerRoster(fantasy, league, b, rosterB, "p8");
  a.cash = 100;
  const offer = createTransferOffer(fantasy, league, a, { sellerManagerId: b.id, targetPlayerId: "p10", offeredPlayerId: "p5", cash: 10 }, league.market);
  respondTransferOffer(fantasy, league, b, offer.id, true);
  assert.equal(a.roster.some((entry) => entry.playerId === "p10"), true);
  assert.equal(b.roster.some((entry) => entry.playerId === "p5"), true);
  assert.equal(a.cash, 90);
  b.roster.push({ playerId: "p6", price: 50 });
  assert.throws(() => executeFantasyClausulazo(fantasy, league, a, b.id, "p6"), /insignia/);
});

test("clausulazo charges the fantasy value, uses the weekly token and preserves seller keeper", () => {
  const { fantasy, league, a, b, rosterA, rosterB } = fixture();
  setManagerRoster(fantasy, league, a, rosterA, "p1");
  setManagerRoster(fantasy, league, b, rosterB, "p8");
  a.cash = 100;
  executeFantasyClausulazo(fantasy, league, a, b.id, "p11", "p5");
  assert.equal(a.cash, 60);
  assert.equal(b.cash, 40);
  assert.equal(a.clausulazoUsed, true);
  assert.equal(a.roster.some((entry) => entry.playerId === "p11"), true);
  assert.throws(() => executeFantasyClausulazo(fantasy, league, a, b.id, "p10", "p4"), /Ya utilizaste/);
});

test("clausulazo cannot take a seller's last goalkeeper", () => {
  const { fantasy, league, a, b, rosterA, rosterB } = fixture();
  setManagerRoster(fantasy, league, a, rosterA, "p1");
  setManagerRoster(fantasy, league, b, rosterB, "p8");
  a.cash = 100;
  assert.throws(() => executeFantasyClausulazo(fantasy, league, a, b.id, "p8", "p5"), /último portero/);
});
