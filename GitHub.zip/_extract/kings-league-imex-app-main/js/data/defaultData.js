// ============================================================================
// KINGS LEAGUE IMEX - DATOS DE DEMOSTRACIÓN (SEED DATA)
// ============================================================================

export const DEFAULT_LEAGUE_INFO = {
  name: "KINGS LEAGUE IMEX",
  tagline: "LA LIGA. TU EQUIPO. TU MOMENTO.",
  season: "TEMPORADA 2026",
  format: "Fútbol 7 Escolar - Torneo por jornadas",
  generationLogo: null,
  budgetPerTeam: 200,
  winReward: 50,
  drawReward: 10,
  lossReward: 0,
  qualificationReward: 50,
  groupStageSettled: false,
};

export const DEFAULT_TEAMS = [
  {
    id: "team-1",
    name: "Los Cuervos FC",
    shortName: "CUE",
    president: "Mateo Ramos",
    group: "A",
    color: "#E5A93C",
    secondaryColor: "#111111",
    logoText: "🦅",
    logoBg: "linear-gradient(135deg, #1A1A1A, #2A2A2A)",
    balance: 85,
    squadValue: 200,
    clausulazoUsed: false,
    status: "active",
    crestUrl: "",
  },
  {
    id: "team-2",
    name: "Titanes del IMEX",
    shortName: "TIT",
    president: "Diego Álvarez",
    group: "A",
    color: "#00E5FF",
    secondaryColor: "#0D223A",
    logoText: "⚡",
    logoBg: "linear-gradient(135deg, #0A192F, #005F73)",
    balance: 60,
    squadValue: 200,
    clausulazoUsed: false,
    status: "active",
    crestUrl: "",
  },
  {
    id: "team-3",
    name: "Rayo Imperial",
    shortName: "RAY",
    president: "Sofía Morales",
    group: "A",
    color: "#FFEA00",
    secondaryColor: "#332200",
    logoText: "👑",
    logoBg: "linear-gradient(135deg, #2D2305, #5A450A)",
    balance: 110,
    squadValue: 200,
    clausulazoUsed: false,
    status: "active",
    crestUrl: "",
  },
  {
    id: "team-4",
    name: "Furia Azteca",
    shortName: "FUR",
    president: "Lucas Hernández",
    group: "A",
    color: "#FF2E4D",
    secondaryColor: "#2B050B",
    logoText: "🔥",
    logoBg: "linear-gradient(135deg, #3A050D, #7F0E1E)",
    balance: 50,
    squadValue: 200,
    clausulazoUsed: true,
    status: "active",
    crestUrl: "",
  },
  {
    id: "team-5",
    name: "Galácticos IMEX",
    shortName: "GAL",
    president: "Sebastián Cruz",
    group: "B",
    color: "#A855F7",
    secondaryColor: "#1A0B2E",
    logoText: "✨",
    logoBg: "linear-gradient(135deg, #1C0C33, #431975)",
    balance: 90,
    squadValue: 200,
    clausulazoUsed: false,
    status: "active",
    crestUrl: "",
  },
  {
    id: "team-6",
    name: "Vikingos FC",
    shortName: "VIK",
    president: "Camila Navarro",
    group: "B",
    color: "#38BDF8",
    secondaryColor: "#082F49",
    logoText: "🛡️",
    logoBg: "linear-gradient(135deg, #082F49, #0369A1)",
    balance: 75,
    squadValue: 200,
    clausulazoUsed: false,
    status: "active",
    crestUrl: "",
  },
  {
    id: "team-7",
    name: "Dragones Negros",
    shortName: "DRA",
    president: "Emilio Romero",
    group: "B",
    color: "#22C55E",
    secondaryColor: "#052E16",
    logoText: "🐉",
    logoBg: "linear-gradient(135deg, #052E16, #14532D)",
    balance: 40,
    squadValue: 200,
    clausulazoUsed: false,
    status: "active",
    crestUrl: "",
  },
  {
    id: "team-8",
    name: "Halcones Dorados",
    shortName: "HAL",
    president: "Valeria Ortiz",
    group: "B",
    color: "#F59E0B",
    secondaryColor: "#351F02",
    logoText: "🦅",
    logoBg: "linear-gradient(135deg, #351F02, #78350F)",
    balance: 95,
    squadValue: 200,
    clausulazoUsed: false,
    status: "active",
    crestUrl: "",
  },
];

export const DEFAULT_PLAYERS = [
  // Team 1: Los Cuervos (55 + 35 + 30 + 25 + 25 + 15 + 15 = 200M)
  { id: "p-101", teamId: "team-1", name: "Carlos 'El Cuervo' Mendoza", number: 10, position: "DEL", value: 55, isInsignia: true, goals: 6, assists: 3, yellowCards: 1, redCards: 0, matchesPlayed: 2, status: "protected", photoUrl: "" },
  { id: "p-102", teamId: "team-1", name: "Rodrigo Salazar", number: 1, position: "POR", value: 35, isInsignia: false, goals: 0, assists: 1, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-103", teamId: "team-1", name: "Alejandro Peña", number: 4, position: "DEF", value: 30, isInsignia: false, goals: 1, assists: 0, yellowCards: 2, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-104", teamId: "team-1", name: "Iker Domínguez", number: 3, position: "DEF", value: 25, isInsignia: false, goals: 0, assists: 1, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-105", teamId: "team-1", name: "Mauricio Luna", number: 8, position: "MED", value: 25, isInsignia: false, goals: 2, assists: 2, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-106", teamId: "team-1", name: "Javier Vargas", number: 6, position: "MED", value: 15, isInsignia: false, goals: 0, assists: 1, yellowCards: 1, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-107", teamId: "team-1", name: "Daniel Rivas", number: 9, position: "DEL", value: 15, isInsignia: false, goals: 1, assists: 0, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },

  // Team 2: Titanes del IMEX (60 + 35 + 30 + 25 + 20 + 15 + 15 = 200M)
  { id: "p-201", teamId: "team-2", name: "Joaquín 'Trueno' Silva", number: 7, position: "DEL", value: 60, isInsignia: true, goals: 5, assists: 2, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "protected", photoUrl: "" },
  { id: "p-202", teamId: "team-2", name: "Santiago Garza", number: 13, position: "POR", value: 35, isInsignia: false, goals: 0, assists: 0, yellowCards: 1, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-203", teamId: "team-2", name: "Fernando Torres", number: 5, position: "DEF", value: 30, isInsignia: false, goals: 1, assists: 1, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-204", teamId: "team-2", name: "Guillermo Lozano", number: 2, position: "DEF", value: 25, isInsignia: false, goals: 0, assists: 0, yellowCards: 2, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-205", teamId: "team-2", name: "Gael Pineda", number: 8, position: "MED", value: 20, isInsignia: false, goals: 1, assists: 3, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-206", teamId: "team-2", name: "Pablo Carmona", number: 14, position: "MED", value: 15, isInsignia: false, goals: 0, assists: 1, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-207", teamId: "team-2", name: "Andrés Figueroa", number: 11, position: "DEL", value: 15, isInsignia: false, goals: 1, assists: 0, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },

  // Team 3: Rayo Imperial (55 + 35 + 30 + 25 + 25 + 15 + 15 = 200M)
  { id: "p-301", teamId: "team-3", name: "Ignacio 'Rey' Benítez", number: 10, position: "MED", value: 55, isInsignia: true, goals: 4, assists: 4, yellowCards: 1, redCards: 0, matchesPlayed: 2, status: "protected", photoUrl: "" },
  { id: "p-302", teamId: "team-3", name: "Bruno Valdés", number: 1, position: "POR", value: 35, isInsignia: false, goals: 0, assists: 0, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-303", teamId: "team-3", name: "Leonardo Castro", number: 4, position: "DEF", value: 30, isInsignia: false, goals: 0, assists: 1, yellowCards: 1, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-304", teamId: "team-3", name: "Mario Escalante", number: 22, position: "DEF", value: 25, isInsignia: false, goals: 0, assists: 0, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-305", teamId: "team-3", name: "Axel Villalobos", number: 8, position: "MED", value: 25, isInsignia: false, goals: 2, assists: 1, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-306", teamId: "team-3", name: "Hugo Santana", number: 17, position: "DEL", value: 15, isInsignia: false, goals: 1, assists: 0, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-307", teamId: "team-3", name: "Enrique Marín", number: 9, position: "DEL", value: 15, isInsignia: false, goals: 2, assists: 0, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },

  // Team 4: Furia Azteca (60 + 30 + 30 + 25 + 25 + 15 + 15 = 200M)
  { id: "p-401", teamId: "team-4", name: "Maximiliano 'Jaguar' Lara", number: 9, position: "DEL", value: 60, isInsignia: true, goals: 4, assists: 1, yellowCards: 2, redCards: 0, matchesPlayed: 2, status: "protected", photoUrl: "" },
  { id: "p-402", teamId: "team-4", name: "Damián Fuentes", number: 1, position: "POR", value: 30, isInsignia: false, goals: 0, assists: 0, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-403", teamId: "team-4", name: "Emiliano Soto", number: 3, position: "DEF", value: 30, isInsignia: false, goals: 0, assists: 1, yellowCards: 3, redCards: 1, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-404", teamId: "team-4", name: "Ángel Méndez", number: 4, position: "DEF", value: 25, isInsignia: false, goals: 0, assists: 0, yellowCards: 1, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-405", teamId: "team-4", name: "Tadeo Corona", number: 6, position: "MED", value: 25, isInsignia: false, goals: 1, assists: 2, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-406", teamId: "team-4", name: "Samuel Galindo", number: 11, position: "MED", value: 15, isInsignia: false, goals: 1, assists: 1, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-407", teamId: "team-4", name: "Rodrigo Cárdenas", number: 21, position: "DEL", value: 15, isInsignia: false, goals: 0, assists: 0, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },

  // Team 5: Galácticos IMEX (55 + 35 + 30 + 25 + 25 + 15 + 15 = 200M)
  { id: "p-501", teamId: "team-5", name: "Lucas 'Cometa' Beltrán", number: 10, position: "MED", value: 55, isInsignia: true, goals: 5, assists: 3, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "protected", photoUrl: "" },
  { id: "p-502", teamId: "team-5", name: "Adrián Cordero", number: 12, position: "POR", value: 35, isInsignia: false, goals: 0, assists: 0, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-503", teamId: "team-5", name: "Martín Quiroz", number: 2, position: "DEF", value: 30, isInsignia: false, goals: 1, assists: 0, yellowCards: 1, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-504", teamId: "team-5", name: "Nicolás Barrera", number: 15, position: "DEF", value: 25, isInsignia: false, goals: 0, assists: 0, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-505", teamId: "team-5", name: "Matías Esparza", number: 8, position: "MED", value: 25, isInsignia: false, goals: 1, assists: 2, yellowCards: 1, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-506", teamId: "team-5", name: "Cristóbal Solís", number: 18, position: "DEL", value: 15, isInsignia: false, goals: 1, assists: 1, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-507", teamId: "team-5", name: "Benjamín Parra", number: 7, position: "DEL", value: 15, isInsignia: false, goals: 0, assists: 1, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },

  // Team 6: Vikingos FC (50 + 40 + 30 + 25 + 25 + 15 + 15 = 200M)
  { id: "p-601", teamId: "team-6", name: "Torben 'Berserker' Lind", number: 9, position: "DEL", value: 50, isInsignia: true, goals: 3, assists: 2, yellowCards: 1, redCards: 0, matchesPlayed: 2, status: "protected", photoUrl: "" },
  { id: "p-602", teamId: "team-6", name: "Óscar Valenzuela", number: 1, position: "POR", value: 40, isInsignia: false, goals: 0, assists: 0, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-603", teamId: "team-6", name: "Erik Morales", number: 5, position: "DEF", value: 30, isInsignia: false, goals: 0, assists: 1, yellowCards: 2, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-604", teamId: "team-6", name: "Iván Cervantes", number: 3, position: "DEF", value: 25, isInsignia: false, goals: 0, assists: 0, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-605", teamId: "team-6", name: "Raúl Castañeda", number: 10, position: "MED", value: 25, isInsignia: false, goals: 2, assists: 1, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-606", teamId: "team-6", name: "Manuel Aranda", number: 16, position: "MED", value: 15, isInsignia: false, goals: 0, assists: 0, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-607", teamId: "team-6", name: "Felipe Rosas", number: 19, position: "DEL", value: 15, isInsignia: false, goals: 1, assists: 0, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },

  // Team 7: Dragones Negros (55 + 35 + 30 + 25 + 25 + 15 + 15 = 200M)
  { id: "p-701", teamId: "team-7", name: "Kevin 'Fénix' Orozco", number: 11, position: "DEL", value: 55, isInsignia: true, goals: 2, assists: 1, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "protected", photoUrl: "" },
  { id: "p-702", teamId: "team-7", name: "Esteban Zepeda", number: 1, position: "POR", value: 35, isInsignia: false, goals: 0, assists: 0, yellowCards: 1, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-703", teamId: "team-7", name: "Alan Del Valle", number: 4, position: "DEF", value: 30, isInsignia: false, goals: 0, assists: 0, yellowCards: 1, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-704", teamId: "team-7", name: "Rubén Pacheco", number: 2, position: "DEF", value: 25, isInsignia: false, goals: 0, assists: 0, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-705", teamId: "team-7", name: "César Villaseñor", number: 8, position: "MED", value: 25, isInsignia: false, goals: 1, assists: 0, yellowCards: 2, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-706", teamId: "team-7", name: "David Alcocer", number: 6, position: "MED", value: 15, isInsignia: false, goals: 0, assists: 1, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-707", teamId: "team-7", name: "Tomás Guadarrama", number: 20, position: "DEL", value: 15, isInsignia: false, goals: 0, assists: 0, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },

  // Team 8: Halcones Dorados (55 + 35 + 30 + 25 + 25 + 15 + 15 = 200M)
  { id: "p-801", teamId: "team-8", name: "Gabriel 'Halcón' Navarro", number: 10, position: "DEL", value: 55, isInsignia: true, goals: 5, assists: 2, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "protected", photoUrl: "" },
  { id: "p-802", teamId: "team-8", name: "Lorenzo Barajas", number: 1, position: "POR", value: 35, isInsignia: false, goals: 0, assists: 0, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-803", teamId: "team-8", name: "Álvaro Ceballos", number: 3, position: "DEF", value: 30, isInsignia: false, goals: 1, assists: 0, yellowCards: 1, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-804", teamId: "team-8", name: "Héctor Palacios", number: 4, position: "DEF", value: 25, isInsignia: false, goals: 0, assists: 1, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-805", teamId: "team-8", name: "Ignacio Rendón", number: 8, position: "MED", value: 25, isInsignia: false, goals: 2, assists: 1, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-806", teamId: "team-8", name: "Bernardo Fonseca", number: 15, position: "MED", value: 15, isInsignia: false, goals: 0, assists: 2, yellowCards: 1, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
  { id: "p-807", teamId: "team-8", name: "Joaquín Leal", number: 17, position: "DEL", value: 15, isInsignia: false, goals: 1, assists: 0, yellowCards: 0, redCards: 0, matchesPlayed: 2, status: "available", photoUrl: "" },
];

export const DEFAULT_MATCHES = [
  {
    id: "match-101",
    matchday: 1,
    phase: "groups",
    group: "A",
    homeTeamId: "team-1",
    awayTeamId: "team-2",
    homeScore: 4,
    awayScore: 2,
    status: "finished",
    date: "2026-09-15",
    time: "10:30",
    pitch: "Cancha Principal IMEX",
    mvpPlayerId: "p-101",
    cardsUsed: [
      { teamId: "team-1", cardName: "Gol Doble (2 min)", result: "Anotó 2 goles con valor x2" },
      { teamId: "team-2", cardName: "Penalti Presidente", result: "Gol convertido por Diego Álvarez" }
    ],
    diceEvent: "Dado dinámico: Minuto 18 -> 3vs3 durante 3 minutos",
    scorers: [
      { playerId: "p-101", teamId: "team-1", minute: 4, type: "regular" },
      { playerId: "p-101", teamId: "team-1", minute: 14, type: "doble" },
      { playerId: "p-105", teamId: "team-1", minute: 28, type: "regular" },
      { playerId: "p-201", teamId: "team-2", minute: 11, type: "regular" },
      { playerId: "p-205", teamId: "team-2", minute: 22, type: "penalti_presi" }
    ],
    bookings: [
      { playerId: "p-103", teamId: "team-1", card: "yellow", minute: 16 },
      { playerId: "p-202", teamId: "team-2", card: "yellow", minute: 25 }
    ],
    notes: "Clásico inaugural de alto voltaje. Los Cuervos aprovecharon la carta de gol doble.",
  },
  {
    id: "match-102",
    matchday: 1,
    phase: "groups",
    group: "A",
    homeTeamId: "team-3",
    awayTeamId: "team-4",
    homeScore: 3,
    awayScore: 3,
    status: "finished",
    date: "2026-09-15",
    time: "11:15",
    pitch: "Cancha 2 IMEX",
    mvpPlayerId: "p-301",
    cardsUsed: [
      { teamId: "team-3", cardName: "Sanción 2 min", result: "Lucas Lara expulsado temporalmente" },
      { teamId: "team-4", cardName: "Comodín", result: "Eligió Gol Doble en minuto 26" }
    ],
    diceEvent: "Dado dinámico: Minuto 18 -> 2vs2 sin portero",
    scorers: [
      { playerId: "p-301", teamId: "team-3", minute: 7, type: "regular" },
      { playerId: "p-305", teamId: "team-3", minute: 19, type: "regular" },
      { playerId: "p-307", teamId: "team-3", minute: 29, type: "regular" },
      { playerId: "p-401", teamId: "team-4", minute: 12, type: "regular" },
      { playerId: "p-401", teamId: "team-4", minute: 27, type: "doble" }
    ],
    bookings: [
      { playerId: "p-403", teamId: "team-4", card: "yellow", minute: 15 },
      { playerId: "p-403", teamId: "team-4", card: "red", minute: 30 }
    ],
    notes: "Empate dramático en el último minuto con gol de Furia Azteca usando carta Comodín.",
  },
  {
    id: "match-103",
    matchday: 1,
    phase: "groups",
    group: "B",
    homeTeamId: "team-5",
    awayTeamId: "team-6",
    homeScore: 5,
    awayScore: 2,
    status: "finished",
    date: "2026-09-16",
    time: "10:30",
    pitch: "Cancha Principal IMEX",
    mvpPlayerId: "p-501",
    cardsUsed: [
      { teamId: "team-5", cardName: "Gol Doble (2 min)", result: "Gol doble al min 22" },
      { teamId: "team-6", cardName: "Robar Carta", result: "Robó carta de penalti rival" }
    ],
    diceEvent: "Dado dinámico: Minuto 18 -> 1vs1 con portero",
    scorers: [
      { playerId: "p-501", teamId: "team-5", minute: 5, type: "regular" },
      { playerId: "p-501", teamId: "team-5", minute: 15, type: "regular" },
      { playerId: "p-501", teamId: "team-5", minute: 23, type: "doble" },
      { playerId: "p-503", teamId: "team-5", minute: 29, type: "regular" },
      { playerId: "p-601", teamId: "team-6", minute: 10, type: "regular" },
      { playerId: "p-605", teamId: "team-6", minute: 18, type: "1vs1" }
    ],
    bookings: [
      { playerId: "p-603", teamId: "team-6", card: "yellow", minute: 24 }
    ],
    notes: "Exhibición galáctica de Beltrán con hat-trick y control del ritmo.",
  },
  {
    id: "match-104",
    matchday: 1,
    phase: "groups",
    group: "B",
    homeTeamId: "team-7",
    awayTeamId: "team-8",
    homeScore: 1,
    awayScore: 4,
    status: "finished",
    date: "2026-09-16",
    time: "11:15",
    pitch: "Cancha 2 IMEX",
    mvpPlayerId: "p-801",
    cardsUsed: [
      { teamId: "team-8", cardName: "Gol Doble (2 min)", result: "Gol doble al min 15" }
    ],
    diceEvent: "Dado dinámico: Minuto 18 -> 4vs4",
    scorers: [
      { playerId: "p-701", teamId: "team-7", minute: 8, type: "regular" },
      { playerId: "p-801", teamId: "team-8", minute: 12, type: "regular" },
      { playerId: "p-801", teamId: "team-8", minute: 16, type: "doble" },
      { playerId: "p-805", teamId: "team-8", minute: 24, type: "regular" }
    ],
    bookings: [
      { playerId: "p-702", teamId: "team-7", card: "yellow", minute: 20 },
      { playerId: "p-803", teamId: "team-8", card: "yellow", minute: 27 }
    ],
    notes: "Halcones desplegó gran verticalidad y castigó los errores de Dragones.",
  },
  {
    id: "match-201",
    matchday: 2,
    phase: "groups",
    group: "A",
    homeTeamId: "team-1",
    awayTeamId: "team-3",
    homeScore: null,
    awayScore: null,
    status: "scheduled",
    date: "2026-09-24",
    time: "10:30",
    pitch: "Cancha Principal IMEX",
    mvpPlayerId: null,
    cardsUsed: [],
    diceEvent: "Pendiente",
    scorers: [],
    bookings: [],
    notes: "Duelo de invictos en el Grupo A. Choque por el liderato.",
  },
  {
    id: "match-202",
    matchday: 2,
    phase: "groups",
    group: "A",
    homeTeamId: "team-2",
    awayTeamId: "team-4",
    homeScore: null,
    awayScore: null,
    status: "scheduled",
    date: "2026-09-24",
    time: "11:15",
    pitch: "Cancha 2 IMEX",
    mvpPlayerId: null,
    cardsUsed: [],
    diceEvent: "Pendiente",
    scorers: [],
    bookings: [],
    notes: "Urgencia total de puntos para evitar la zona de eliminación.",
  },
  {
    id: "match-203",
    matchday: 2,
    phase: "groups",
    group: "B",
    homeTeamId: "team-5",
    awayTeamId: "team-8",
    homeScore: null,
    awayScore: null,
    status: "scheduled",
    date: "2026-09-25",
    time: "10:30",
    pitch: "Cancha Principal IMEX",
    mvpPlayerId: null,
    cardsUsed: [],
    diceEvent: "Pendiente",
    scorers: [],
    bookings: [],
    notes: "Los dos ataques más prolíficos frente a frente.",
  },
  {
    id: "match-204",
    matchday: 2,
    phase: "groups",
    group: "B",
    homeTeamId: "team-6",
    awayTeamId: "team-7",
    homeScore: null,
    awayScore: null,
    status: "scheduled",
    date: "2026-09-25",
    time: "11:15",
    pitch: "Cancha 2 IMEX",
    mvpPlayerId: null,
    cardsUsed: [],
    diceEvent: "Pendiente",
    scorers: [],
    bookings: [],
    notes: "Duelo a vida o muerte en el fondo de la tabla del Grupo B.",
  },
  {
    id: "match-semi-1",
    matchday: 3,
    phase: "semifinals",
    group: null,
    title: "SEMIFINAL 1",
    homeTeamId: "team-1",
    awayTeamId: "team-8",
    homeScore: null,
    awayScore: null,
    status: "scheduled",
    date: "2026-10-01",
    time: "10:30",
    pitch: "Estadio IMEX (Cancha 1)",
    notes: "1° Grupo A vs 2° Grupo B",
  },
  {
    id: "match-semi-2",
    matchday: 3,
    phase: "semifinals",
    group: null,
    title: "SEMIFINAL 2",
    homeTeamId: "team-5",
    awayTeamId: "team-3",
    homeScore: null,
    awayScore: null,
    status: "scheduled",
    date: "2026-10-01",
    time: "11:15",
    pitch: "Estadio IMEX (Cancha 1)",
    notes: "1° Grupo B vs 2° Grupo A",
  },
  {
    id: "match-final",
    matchday: 4,
    phase: "final",
    group: null,
    title: "GRAN FINAL KINGS LEAGUE IMEX",
    homeTeamId: null,
    awayTeamId: null,
    homeScore: null,
    awayScore: null,
    status: "scheduled",
    date: "2026-10-08",
    time: "10:45",
    pitch: "Estadio IMEX (Cancha 1)",
    notes: "Previa con Subasta Final de refuerzos.",
  }
];

export const DEFAULT_MARKET_STATE = {
  mode: "auto", // "auto" = solo miércoles (por calendario real) | "open" | "closed"
  currentOpenWeek: null,
  transfers: [
    {
      id: "tr-001",
      buyerTeamId: "team-4",
      sellerTeamId: "team-2",
      playerId: "p-207",
      offeredPlayerIds: [],
      price: 15,
      type: "clausulazo",
      status: "completed",
      date: "2026-09-17 14:30",
      notes: "Clausulazo ejecutado por Furia Azteca. Cláusula pagada íntegra (15M).",
    },
    {
      id: "tr-002",
      buyerTeamId: "team-1",
      sellerTeamId: "team-6",
      playerId: "p-607",
      offeredPlayerIds: ["p-107"],
      price: 5,
      type: "swap_and_cash",
      status: "pending",
      date: "2026-09-18 09:15",
      notes: "Propuesta de intercambio: Daniel Rivas + 5M por Felipe Rosas.",
    }
  ]
};

export const DEFAULT_FINANCES = [
  { id: "fin-1", teamId: "team-1", type: "income", concept: "Victoria Jornada 01 (vs Titanes)", amount: 50, date: "2026-09-15" },
  { id: "fin-2", teamId: "team-1", type: "expense", concept: "Comisión inicial de registro", amount: 15, date: "2026-09-10" },
  { id: "fin-3", teamId: "team-2", type: "expense", concept: "Derrota Jornada 01", amount: 0, date: "2026-09-15" },
  { id: "fin-4", teamId: "team-2", type: "income", concept: "Ingreso por Clausulazo (Andrés Figueroa)", amount: 15, date: "2026-09-17" },
  { id: "fin-5", teamId: "team-3", type: "income", concept: "Empate Jornada 01 (vs Furia Azteca)", amount: 10, date: "2026-09-15" },
  { id: "fin-6", teamId: "team-4", type: "income", concept: "Empate Jornada 01 (vs Rayo Imperial)", amount: 10, date: "2026-09-15" },
  { id: "fin-7", teamId: "team-4", type: "expense", concept: "Pago de Clausulazo por Andrés Figueroa", amount: 15, date: "2026-09-17" },
  { id: "fin-8", teamId: "team-5", type: "income", concept: "Victoria Jornada 01 (vs Vikingos)", amount: 50, date: "2026-09-16" },
  { id: "fin-9", teamId: "team-8", type: "income", concept: "Victoria Jornada 01 (vs Dragones)", amount: 50, date: "2026-09-16" },
];

export const DEFAULT_RULES_CARDS = [
  { id: "card-1", name: "Gol Doble", icon: "⚡⚡", badgeColor: "#FFD700", timing: "En cualquier momento (1 por tiempo)", duration: "2 Minutos", description: "Todos los goles marcados por tu equipo durante los siguientes 2 minutos contarán por 2 en el marcador oficial.", rarity: "Épica" },
  { id: "card-2", name: "Penalti Presidente", icon: "👑", badgeColor: "#00FF66", timing: "Primeros 30 minutos de partido", duration: "Inmediato", description: "El Presidente del equipo baja a la cancha para cobrar un tiro penal decisivo contra el guardameta rival.", rarity: "Legendaria" },
  { id: "card-3", name: "Sanción 2 Minutos", icon: "🟥", badgeColor: "#FF2E4D", timing: "Al iniciar un saque o reanudación", duration: "2 Minutos", description: "Elige a un jugador de campo del rival (no portero ni insignia) para que abandone el terreno de juego durante 2 minutos.", rarity: "Rara" },
  { id: "card-4", name: "Comodín Total", icon: "🃏", badgeColor: "#A855F7", timing: "Antes de los últimos 5 minutos", duration: "Variable", description: "Permite al entrenador o presidente elegir en secreto cualquiera de las cartas del reglamento y ejecutarla al instante.", rarity: "Mítica" },
  { id: "card-5", name: "Robo de Carta", icon: "🥷", badgeColor: "#00E5FF", timing: "Antes del pitazo inicial o en el descanso", duration: "Inmediato", description: "Roba la carta secreta en posesión del equipo rival antes de que la activen y utilízala a tu favor.", rarity: "Épica" },
  { id: "card-6", name: "Jugador Estrella x2", icon: "⭐", badgeColor: "#FFE600", timing: "Al inicio del segundo tiempo", duration: "Todo el segundo tiempo", description: "Designa a un jugador de campo. Cada gol marcado por él sumará 1.5 goles adicionales al marcador.", rarity: "Rara" }
];

export const DEFAULT_DICE_RULES = [
  { id: "dice-1", roll: "1 vs 1 con Portero", symbol: "⚀", description: "Se retiran todos los jugadores de campo. Queda 1 jugador contra 1 con sus respectivos guardametas.", timeframe: "Minuto 18 al 20 del primer tiempo", intensity: "Máxima Tensión" },
  { id: "dice-2", roll: "2 vs 2 sin Porteros", symbol: "⚁", description: "Juegan únicamente dos jugadores por bando en cancha completa con arcos vacíos. Prohibido tocar con las manos.", timeframe: "Minuto 18 al 20 del primer tiempo", intensity: "Caos Total" },
  { id: "dice-3", roll: "3 vs 3", symbol: "⚂", description: "3 futbolistas por bando incluyendo portero. Partidos de ida y vuelta constantes.", timeframe: "Minuto 18 al 20 del primer tiempo", intensity: "Velocidad Pura" },
  { id: "dice-4", roll: "4 vs 4", symbol: "⚃", description: "4 futbolistas por bando. Mayor espacio para transiciones rápidas y contragolpes letales.", timeframe: "Minuto 18 al 20 del primer tiempo", intensity: "Estratégico" }
];

export const DEFAULT_ANNOUNCEMENTS = [
  { id: "ann-1", title: "¡APERTURA OFICIAL DEL MERCADO DE FICHAJES!", category: "MERCADO", date: "2026-09-22", time: "08:00", important: true, content: "Queda formalmente habilitada la ventana de traspasos semanal para los 8 clubes de la KINGS LEAGUE IMEX. Recuerden las reglas: Cada club tiene derecho a 1 solo CLAUSULAZO por mercado. Los Jugadores Insignia cuentan con inmunidad blindada. ¡Negocien con sabiduría!", author: "Comité Organizador IMEX" },
  { id: "ann-2", title: "Horarios Oficiales - Jornada 02", category: "HORARIOS", date: "2026-09-21", time: "15:30", important: false, content: "El jueves 24 y viernes 25 de septiembre se disputarán los encuentros de la Jornada 02. Consulta el calendario para ver cancha y hora de cada partido.", author: "Dirección de Torneo" },
  { id: "ann-3", title: "Resolución Disciplinaria: Sanción a Emiliano Soto (Furia Azteca)", category: "SANCIONES", date: "2026-09-17", time: "12:00", important: true, content: "Tras la doble amarilla y expulsión en el minuto 30 del duelo frente a Rayo Imperial, el zaguero Emiliano Soto queda suspendido por 1 jornada. No podrá alinear en la Jornada 02 frente a Titanes.", author: "Tribunal de Penas IMEX" }
];

export const DEFAULT_AUCTION_PLAYERS = [
  { id: "auc-1", playerId: "p-701", playerName: "Kevin 'Fénix' Orozco", previousTeamName: "Dragones Negros", baseValue: 55, bidTeamA: 65, bidTeamB: 70, winnerTeamId: null, finalPrice: 0, status: "active" },
  { id: "auc-2", playerId: "p-601", playerName: "Torben 'Berserker' Lind", previousTeamName: "Vikingos FC", baseValue: 50, bidTeamA: 55, bidTeamB: 50, winnerTeamId: null, finalPrice: 0, status: "active" }
];

export const DEFAULT_DRAFT_STATE = {
  status: "setup",
  secondsPerPick: 45,
  order: [],
  round: 1,
  pickIndex: 0,
  currentTeamId: null,
  turnStartedAt: null,
  poolPlayerIds: [],
  picks: [],
  skippedTurns: [],
};

export const DEFAULT_USERS = [
  {
    id: "u-admin",
    username: "organizador",
    name: "SENIORS",
    role: "ADMIN",
    teamId: null,
    avatar: "👑"
  },
  {
    id: "u-cuervos",
    username: "cuervos_presi",
    name: "Mateo Ramos (Pres. Los Cuervos)",
    role: "PRESIDENT",
    teamId: "team-1",
    avatar: "🦅"
  },
  {
    id: "u-titanes",
    username: "titanes_presi",
    name: "Diego Álvarez (Pres. Titanes)",
    role: "PRESIDENT",
    teamId: "team-2",
    avatar: "⚡"
  },
  {
    id: "u-rayo",
    username: "rayo_presi",
    name: "Sofía Morales (Pres. Rayo Imperial)",
    role: "PRESIDENT",
    teamId: "team-3",
    avatar: "👑"
  },
  {
    id: "u-furia",
    username: "furia_presi",
    name: "Lucas Hernández (Pres. Furia Azteca)",
    role: "PRESIDENT",
    teamId: "team-4",
    avatar: "🔥"
  },
  {
    id: "u-galacticos",
    username: "galacticos_presi",
    name: "Sebastián Cruz (Pres. Galácticos IMEX)",
    role: "PRESIDENT",
    teamId: "team-5",
    avatar: "✨"
  },
  {
    id: "u-vikingos",
    username: "vikingos_presi",
    name: "Camila Navarro (Pres. Vikingos FC)",
    role: "PRESIDENT",
    teamId: "team-6",
    avatar: "🛡️"
  },
  {
    id: "u-dragones",
    username: "dragones_presi",
    name: "Emilio Romero (Pres. Dragones Negros)",
    role: "PRESIDENT",
    teamId: "team-7",
    avatar: "🐉"
  },
  {
    id: "u-halcones",
    username: "halcones_presi",
    name: "Valeria Ortiz (Pres. Halcones Dorados)",
    role: "PRESIDENT",
    teamId: "team-8",
    avatar: "🦅"
  },
  {
    id: "u-jugador",
    username: "carlos_mendoza",
    name: "Carlos Mendoza (Insignia Cuervos)",
    role: "PLAYER",
    playerId: "p-101",
    teamId: "team-1",
    avatar: "⭐"
  }
];
