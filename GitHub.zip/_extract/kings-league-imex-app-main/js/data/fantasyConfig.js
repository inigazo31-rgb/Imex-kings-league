export const FANTASY_CONFIG = Object.freeze({
  rosterSize: 5,
  budget: 200,
  cashPerPoint: 1,
  marketAutoDay: 3,
  points: Object.freeze({
    win: 3,
    draw: 1,
    loss: 0,
    goal: Object.freeze({ POR: 10, DEF: 6, MED: 5, DEL: 4 }),
    cleanSheet: 4,
    yellowCard: -1,
    redCard: -3,
    captainMultiplier: 2,
  }),
  limits: Object.freeze({
    maxPlayersPerPosition: 2,
    maxPlayersPerRealTeam: 2,
    managerNameLength: 28,
  }),
});
