import { store } from "./store.js";

const TOKEN_KEY = "KINGS_LEAGUE_IMEX_FANTASY_TOKEN";
const USER_KEY = "KINGS_LEAGUE_IMEX_FANTASY_USER";

export const fantasySession = {
  get user() {
    try { return JSON.parse(sessionStorage.getItem(USER_KEY) || "null"); } catch { return null; }
  },
  clear() {
    sessionStorage.removeItem(TOKEN_KEY);
    sessionStorage.removeItem(USER_KEY);
  },
};

async function request(path, body = null, options = {}) {
  const headers = { "Content-Type": "application/json" };
  const managerToken = sessionStorage.getItem(TOKEN_KEY);
  const token = options.auth === "none" ? "" : options.auth === "app" ? store.apiToken || "" : managerToken || store.apiToken || "";
  if (token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(`/api/fantasy${path}`, {
    method: body === null ? "GET" : "POST",
    headers,
    ...(body === null ? {} : { body: JSON.stringify(body) }),
    cache: "no-store",
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || "No se pudo completar la operación Fantasy.");
  return result;
}

function saveSession(result) {
  sessionStorage.setItem(TOKEN_KEY, result.token);
  sessionStorage.setItem(USER_KEY, JSON.stringify(result.user));
  return result.fantasy;
}

export const fantasyApi = {
  get: () => request(""),
  register: async (name, pin) => saveSession(await request("/register", { name, pin }, { auth: "app" })),
  login: async (name, pin) => saveSession(await request("/login", { name, pin }, { auth: "app" })),
  saveTeam: (roster, captainId) => request("/team", { roster, captainId }),
  buyFreeAgent: (playerId, replacePlayerId = null) => request("/free-agent/buy", { playerId, replacePlayerId }),
  releasePlayer: (playerId) => request("/team/release", { playerId }),
  propose: (offer) => request("/market/offer", offer),
  respond: (offerId, accept) => request("/market/respond", { offerId, accept }),
  clausulazo: (targetManagerId, playerId, replacePlayerId = null) => request("/market/clausulazo", { targetManagerId, playerId, replacePlayerId }),
  admin: (action, payload) => request(`/admin/${action}`, payload),
};
