import { fantasyApi, fantasySession } from "../state/fantasyApi.js";
import { store } from "../state/store.js";
import { toast } from "../components/toast.js";

const safe = (value) => String(value ?? "");

export function renderFantasyView(container) {
  if (container.__fantasyTimer) window.clearInterval(container.__fantasyTimer);
  let activeTab = "table";
  let data = null;

  async function load() {
    try {
      data = await fantasyApi.get();
      if (container.dataset.fantasyDraftDirty === "true" && container.querySelector("#fantasyDraftForm")) return;
      draw();
    } catch (error) {
      container.innerHTML = `<div class="view-animate-fade"><div class="page-header"><div class="page-title-group"><span class="page-category-tag">FANTASY</span><h1 class="page-title">Fantasy Kings League IMEX</h1><p class="page-subtitle">${safe(error.message)}</p></div></div><button class="btn btn-outline-lime" id="fantasyRetry">Reintentar</button></div>`;
      container.querySelector("#fantasyRetry")?.addEventListener("click", load);
    }
  }

  function draw() {
    const me = data.me;
    const roster = me?.roster || [];
    const myManager = me && data.managers.find((manager) => manager.id === me.id);
    const playerMap = new Map(data.players.map((player) => [player.id, player]));
    const heldByOthers = new Set(data.managers.filter((manager) => manager.id !== me?.id).flatMap((manager) => manager.roster.map((entry) => entry.playerId)));
    const draftPlayers = data.players.filter((player) => player.kind === "real" && player.available && !heldByOthers.has(player.id));
    const isComplete = roster.length === data.config.rosterSize;
    const roleBlocked = ["PRESIDENT", "PLAYER", "ADMIN"].includes(store.currentUser.role);
    const tabContent = activeTab === "table" ? renderTable() : activeTab === "team" ? renderTeam() : renderMarket();

    function renderTable() {
      return `<section class="standings-table-container"><table class="standings-table"><thead><tr><th>POS</th><th>MANAGER</th><th>PUNTOS</th><th>GOLES</th><th>CAJA</th></tr></thead><tbody>${data.managers.map((manager, index) => `<tr class="standings-row"><td>${index + 1}</td><td><button class="btn btn-sm btn-outline fantasy-detail-btn" data-manager-id="${manager.id}">${safe(manager.name)}</button></td><td class="standings-pts-col">${manager.points}</td><td>${manager.goals}</td><td>${manager.cash}M</td></tr><tr class="fantasy-detail-row" data-detail-id="${manager.id}" hidden><td colspan="5">${manager.rounds.map((round) => `<div style="padding:0.45rem 0;border-bottom:1px solid var(--border-subtle)"><strong>Jornada ${round.matchday}: ${round.points} pts</strong><span style="color:var(--text-muted)"> · ${round.details.map((detail) => `${safe(detail.name)} ${detail.points}pts`).join(" · ")}</span></div>`).join("") || "Sin puntos registrados."}</td></tr>`).join("") || `<tr><td colspan="5" style="text-align:center;padding:1.5rem">Aún no hay managers Fantasy.</td></tr>`}</tbody></table></section>`;
    }

    function renderTeam() {
      if (roleBlocked) return `<div class="kings-card"><h3 class="kings-card-name">Fantasy para alumnos</h3><p class="kings-card-desc">Los presidentes y jugadores de equipos reales no pueden participar en Fantasy. Cambia a visitante para entrar con tu manager Fantasy.</p></div>`;
      if (!me) return `<div class="kings-card"><h3 class="kings-card-name">Entra a Fantasy</h3><p class="kings-card-desc">Regístrate con un nombre de manager y un PIN de 4 dígitos para armar tu equipo.</p>${authForms()}</div>`;
      if (!isComplete) {
        const selectedOptions = Array.from({ length: data.config.rosterSize }, (_, index) => `<div class="form-group"><label class="form-label">Jugador ${index + 1}</label><div style="display:grid;grid-template-columns:minmax(0,1fr) 90px;gap:.5rem"><select class="form-select fantasy-pick" data-slot="${index}"><option value="">Elegir jugador</option>${draftPlayers.map((player) => `<option value="${player.id}" ${roster[index]?.playerId === player.id ? "selected" : ""}>${safe(player.name)} · ${safe(player.position)} · ${safe(player.realTeamName)}</option>`).join("")}</select><input class="form-control fantasy-price" data-slot="${index}" type="number" min="0" max="200" value="${roster[index]?.price ?? 40}" aria-label="Precio fantasy del jugador ${index + 1}" /></div></div>`).join("");
        return `<div class="kings-card"><h3 class="kings-card-name">Arma tu equipo · ${data.config.budget}M</h3><p class="kings-card-desc">Elige ${data.config.rosterSize} jugadores y reparte exactamente ${data.config.budget}M. Mínimo 1 POR, máximo 2 por posición y 2 por club real.</p><form id="fantasyDraftForm">${selectedOptions}<div class="form-group"><label class="form-label">Capitán (puntuación x${data.config.points.captainMultiplier})</label><select class="form-select" id="fantasyCaptain"><option value="">Elegir capitán</option>${draftPlayers.map((player) => `<option value="${player.id}" ${me.captainId === player.id ? "selected" : ""}>${safe(player.name)}</option>`).join("")}</select></div><div id="fantasyBudgetStatus" class="badge badge-yellow">Total asignado: 200M</div><button class="btn btn-lime" type="submit" style="width:100%;margin-top:1rem">Guardar equipo</button></form></div>`;
      }
      return `<div class="kings-card"><div style="display:flex;justify-content:space-between;align-items:center;gap:1rem;flex-wrap:wrap"><div><h3 class="kings-card-name">${safe(me.name)}</h3><p class="kings-card-desc">Puntos: ${myManager?.points || 0} · Caja: ${me.cash}M · Capitán: ${safe(playerMap.get(me.captainId)?.name || "Sin asignar")}</p></div><button id="fantasyLogout" class="btn btn-sm btn-outline">Salir</button></div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:.75rem;margin-top:1rem">${roster.map((entry) => { const player = playerMap.get(entry.playerId); return `<div class="player-card"><div class="player-card-header"><span class="player-pos-badge pos-${safe(player?.position || "del").toLowerCase()}">${safe(player?.position || "")}</span>${entry.playerId === me.captainId ? `<span class="badge badge-gold">CAPITÁN x2</span>` : ""}</div><div class="player-info"><div class="player-name">${safe(player?.name || "Jugador")}</div><div style="color:var(--text-muted);font-size:.75rem">${safe(player?.realTeamName)} · ${entry.price}M</div></div><button class="btn btn-sm btn-outline fantasy-release" data-player-id="${entry.playerId}">Liberar plaza</button></div>`; }).join("")}</div></div>`;
    }

    function renderMarket() {
      if (!me || !isComplete) return `<div class="kings-card"><h3 class="kings-card-name">Mercado Fantasy</h3><p class="kings-card-desc">Inicia sesión y completa tu equipo para operar.</p></div>`;
      const others = data.managers.filter((manager) => manager.id !== me.id);
      const selectedSeller = others[0];
      const playersOfSeller = selectedSeller?.roster.map((entry) => playerMap.get(entry.playerId)).filter((player) => player?.available !== false) || [];
      const pending = data.offers.filter((offer) => offer.sellerManagerId === me.id && offer.status === "pending");
      return `<div style="display:flex;flex-direction:column;gap:1rem"><div class="market-status-bar"><div class="market-status-info"><div class="market-pulsing-dot ${data.marketOpen ? "" : "closed"}"></div><div><div class="market-status-title">MERCADO FANTASY ${data.marketOpen ? "ABIERTO" : "CERRADO"}</div><div style="font-size:.75rem;color:var(--text-muted)">Usa el mismo calendario y override del mercado real.</div></div></div><span class="badge ${data.marketOpen ? "badge-lime" : "badge-red"}">${data.marketOpen ? "OPERACIONES ACTIVAS" : "AGENTES LIBRES DISPONIBLES"}</span></div>
        <div class="kings-card"><h3 class="kings-card-name">Agentes libres</h3><p class="kings-card-desc">Si tienes cinco jugadores, selecciona en tu equipo a quién reemplazar.</p><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:.75rem">${data.freeAgents.map((agent) => `<div class="player-card"><div class="player-info"><div class="player-name">${safe(agent.name)}</div><div style="color:var(--text-muted)">${safe(agent.position)} · ${agent.value}M</div></div><button class="btn btn-sm btn-outline-lime fantasy-buy-agent" data-player-id="${agent.id}" ${me.cash < agent.value ? "disabled" : ""}>Fichar · ${agent.value}M</button></div>`).join("") || `<p class="kings-card-desc">No hay agentes libres.</p>`}</div></div>
        <div class="kings-card"><h3 class="kings-card-name">Ofertas entre managers</h3><form id="fantasyOfferForm"><div class="form-group"><label class="form-label">Manager vendedor</label><select class="form-select" id="fantasySeller">${others.map((manager) => `<option value="${manager.id}">${safe(manager.name)}</option>`).join("")}</select></div><div class="form-group"><label class="form-label">Jugador objetivo</label><select class="form-select" id="fantasyTarget">${playersOfSeller.map((player) => `<option value="${player.id}">${safe(player.name)} (${safe(player.position)})</option>`).join("")}</select></div><div class="form-group"><label class="form-label">Dinero ofrecido (M)</label><input class="form-control" id="fantasyOfferCash" type="number" min="0" max="${me.cash}" value="0" /></div><div class="form-group"><label class="form-label">Jugador para trueque (opcional)</label><select class="form-select" id="fantasyOffered"><option value="">Solo dinero</option>${roster.map((entry) => `<option value="${entry.playerId}">${safe(playerMap.get(entry.playerId)?.name)} (${entry.price}M)</option>`).join("")}</select></div><button class="btn btn-lime" ${!data.marketOpen || !others.length ? "disabled" : ""}>Enviar oferta</button></form></div>
        ${data.marketOpen ? `<div class="kings-card"><h3 class="kings-card-name">Clausulazos Fantasy · ${me.clausulazoUsed ? "usado esta semana" : "disponible"}</h3><p class="kings-card-desc">Si tienes cinco jugadores, se reemplazará el jugador que selecciones en Mi Equipo.</p><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:.75rem">${others.flatMap((manager) => manager.roster.map((entry) => ({ manager, entry, player: playerMap.get(entry.playerId) }))).filter((item) => item.player?.available !== false).map(({ manager, entry, player }) => `<div class="player-card"><div class="player-info"><div class="player-name">${safe(player?.name)}</div><div style="color:var(--text-muted)">${safe(manager.name)} · ${entry.price}M</div></div><button class="btn btn-sm btn-red fantasy-clausulazo" data-manager-id="${manager.id}" data-player-id="${entry.playerId}" ${me.clausulazoUsed || me.cash < entry.price ? "disabled" : ""}>Clausulazo · ${entry.price}M</button></div>`).join("") || `<p class="kings-card-desc">No hay jugadores transferibles ahora.</p>`}</div></div>` : ""}
        ${pending.length ? `<div class="kings-card"><h3 class="kings-card-name">Ofertas recibidas (${pending.length})</h3>${pending.map((offer) => { const buyer = data.managers.find((manager) => manager.id === offer.buyerManagerId); const player = playerMap.get(offer.targetPlayerId); const offered = playerMap.get(offer.offeredPlayerId); return `<div class="draft-pick-row"><strong>${safe(buyer?.name)} ofrece ${offer.cash}M por ${safe(player?.name)}${offered ? ` + trueque de ${safe(offered.name)}` : ""}</strong><span><button class="btn btn-sm btn-lime fantasy-respond" data-offer-id="${offer.id}" data-accept="true">Aceptar</button> <button class="btn btn-sm btn-red fantasy-respond" data-offer-id="${offer.id}" data-accept="false">Rechazar</button></span></div>`; }).join("")}</div>` : ""}</div>`;
    }

    function authForms() {
      return `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:1rem"><form id="fantasyRegisterForm"><h4>Crear manager</h4><div class="form-group"><label class="form-label">Nombre de manager</label><input class="form-control" name="name" maxlength="28" required /></div><div class="form-group"><label class="form-label">PIN de 4 dígitos</label><input class="form-control" name="pin" inputmode="numeric" pattern="[0-9]{4}" maxlength="4" required /></div><button class="btn btn-lime" ${data.registrationOpen ? "" : "disabled"}>Crear equipo Fantasy</button></form><form id="fantasyLoginForm"><h4>Volver a entrar</h4><div class="form-group"><label class="form-label">Nombre de manager</label><input class="form-control" name="name" required /></div><div class="form-group"><label class="form-label">PIN</label><input class="form-control" name="pin" inputmode="numeric" pattern="[0-9]{4}" maxlength="4" required /></div><button class="btn btn-outline-lime">Entrar</button></form></div><p class="kings-card-desc">${data.registrationOpen ? "Inscripciones abiertas." : "Inscripciones cerradas por el organizador."} El PIN solo sirve para recuperar tu equipo Fantasy.</p>`;
    }

    container.innerHTML = `<div class="view-animate-fade"><div class="page-header"><div class="page-title-group"><span class="page-category-tag">COMPETICIÓN PARA ALUMNOS</span><h1 class="page-title">⚡ FANTASY KINGS LEAGUE</h1><p class="page-subtitle">Elige cinco futbolistas reales, reparte 200M y compite por puntos jornada a jornada.</p></div><div class="tab-nav" id="fantasyTabs"><button class="tab-btn ${activeTab === "table" ? "active" : ""}" data-tab="table">🏆 TABLA</button><button class="tab-btn ${activeTab === "team" ? "active" : ""}" data-tab="team">👥 MI EQUIPO</button><button class="tab-btn ${activeTab === "market" ? "active" : ""}" data-tab="market">💰 MERCADO</button></div></div>${!me && !roleBlocked ? `<div class="kings-card">${authForms()}</div>` : ""}<div id="fantasyContent">${tabContent}</div></div>`;

    container.querySelectorAll("#fantasyTabs [data-tab]").forEach((button) => button.addEventListener("click", () => {
      if (container.dataset.fantasyDraftDirty === "true" && !window.confirm("Tienes cambios sin guardar en tu equipo. ¿Descartarlos?")) return;
      if (container.dataset.fantasyDraftDirty === "true") container.dataset.fantasyDraftDirty = "false";
      activeTab = button.dataset.tab;
      draw();
    }));
    container.querySelectorAll(".fantasy-detail-btn").forEach((button) => button.addEventListener("click", () => {
      const detail = container.querySelector(`[data-detail-id="${button.dataset.managerId}"]`);
      if (detail) detail.hidden = !detail.hidden;
    }));
    container.querySelector("#fantasyRegisterForm")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const fields = new FormData(event.currentTarget);
      try { data = await fantasyApi.register(fields.get("name"), fields.get("pin")); activeTab = "team"; toast.show("Manager creado", "Ahora arma tu roster de cinco jugadores.", "lime"); draw(); } catch (error) { toast.show("Fantasy", error.message, "red"); }
    });
    container.querySelector("#fantasyLoginForm")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const fields = new FormData(event.currentTarget);
      try { data = await fantasyApi.login(fields.get("name"), fields.get("pin")); activeTab = data.me?.roster?.length === 5 ? "team" : "team"; toast.show("Sesión Fantasy", `Bienvenido, ${data.me.name}.`, "lime"); draw(); } catch (error) { toast.show("Fantasy", error.message, "red"); }
    });
    container.querySelector("#fantasyDraftForm")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      const roster = Array.from({ length: data.config.rosterSize }, (_, index) => ({ playerId: container.querySelector(`.fantasy-pick[data-slot="${index}"]`).value, price: Number(container.querySelector(`.fantasy-price[data-slot="${index}"]`).value) }));
      try { await fantasyApi.saveTeam(roster, container.querySelector("#fantasyCaptain").value); container.dataset.fantasyDraftDirty = "false"; data = await fantasyApi.get(); toast.show("Equipo Fantasy", "Tu equipo quedó registrado.", "lime"); draw(); } catch (error) { toast.show("No se pudo guardar", error.message, "red"); }
    });
    container.querySelectorAll(".fantasy-pick, .fantasy-price").forEach((input) => input.addEventListener("input", () => {
      container.dataset.fantasyDraftDirty = "true";
      updateDraftStatus();
    }));
    function updateDraftStatus() {
      const prices = [...container.querySelectorAll(".fantasy-price")].map((input) => Number(input.value) || 0);
      const total = prices.reduce((sum, price) => sum + price, 0);
      const label = container.querySelector("#fantasyBudgetStatus");
      if (label) { label.textContent = `Total asignado: ${total}M`; label.className = `badge ${total === data.config.budget ? "badge-lime" : "badge-yellow"}`; }
      const picked = [...container.querySelectorAll(".fantasy-pick")].map((input) => input.value);
      const captain = container.querySelector("#fantasyCaptain");
      if (captain) {
        const selectedCaptain = captain.value;
        captain.innerHTML = `<option value="">Elegir capitán</option>${picked.filter(Boolean).map((id) => { const player = data.players.find((item) => item.id === id); return player ? `<option value="${player.id}">${safe(player.name)}</option>` : ""; }).join("")}`;
        captain.value = selectedCaptain;
        captain.addEventListener("change", () => { container.dataset.fantasyDraftDirty = "true"; }, { once: true });
      }
    }
    container.querySelector("#fantasyLogout")?.addEventListener("click", () => { fantasySession.clear(); activeTab = "table"; load(); });
    container.querySelector("#fantasyOfferForm")?.addEventListener("submit", async (event) => {
      event.preventDefault();
      try { await fantasyApi.propose({ sellerManagerId: container.querySelector("#fantasySeller").value, targetPlayerId: container.querySelector("#fantasyTarget").value, cash: Number(container.querySelector("#fantasyOfferCash").value), offeredPlayerId: container.querySelector("#fantasyOffered").value || null }); data = await fantasyApi.get(); toast.show("Oferta enviada", "El otro manager puede aceptarla o rechazarla.", "lime"); draw(); } catch (error) { toast.show("Fantasy", error.message, "red"); }
    });
    container.querySelectorAll(".fantasy-buy-agent").forEach((button) => button.addEventListener("click", async () => {
      const replacePlayerId = roster.length >= 5 ? window.prompt(`Escribe el nombre exacto del jugador de tu equipo que quieres reemplazar:\n${roster.map((entry) => playerMap.get(entry.playerId)?.name).join("\n")}`) : null;
      if (roster.length >= 5 && !roster.some((entry) => playerMap.get(entry.playerId)?.name === replacePlayerId)) return;
      const replaceId = roster.find((entry) => playerMap.get(entry.playerId)?.name === replacePlayerId)?.playerId || null;
      try { await fantasyApi.buyFreeAgent(button.dataset.playerId, replaceId); data = await fantasyApi.get(); toast.show("Agente fichado", "Se descontó el valor de tu caja.", "lime"); draw(); } catch (error) { toast.show("Fantasy", error.message, "red"); }
    }));
    container.querySelectorAll(".fantasy-clausulazo").forEach((button) => button.addEventListener("click", async () => {
      const replacePlayerId = roster.length >= 5 ? window.prompt(`Escribe el nombre exacto del jugador de tu equipo que quieres reemplazar:\n${roster.map((entry) => playerMap.get(entry.playerId)?.name).join("\n")}`) : null;
      if (roster.length >= 5 && !roster.some((entry) => playerMap.get(entry.playerId)?.name === replacePlayerId)) return;
      const replaceId = roster.find((entry) => playerMap.get(entry.playerId)?.name === replacePlayerId)?.playerId || null;
      try { await fantasyApi.clausulazo(button.dataset.managerId, button.dataset.playerId, replaceId); data = await fantasyApi.get(); toast.show("Clausulazo Fantasy", "El jugador cambió de equipo.", "lime"); draw(); } catch (error) { toast.show("Fantasy", error.message, "red"); }
    }));
    container.querySelectorAll(".fantasy-release").forEach((button) => button.addEventListener("click", async () => {
      if (!window.confirm("Liberar este jugador deja una plaza vacía en tu equipo. ¿Continuar?")) return;
      try { await fantasyApi.releasePlayer(button.dataset.playerId); data = await fantasyApi.get(); toast.show("Fantasy", "Jugador liberado.", "yellow"); activeTab = "team"; draw(); } catch (error) { toast.show("Fantasy", error.message, "red"); }
    }));
    container.querySelectorAll(".fantasy-respond").forEach((button) => button.addEventListener("click", async () => {
      try { await fantasyApi.respond(button.dataset.offerId, button.dataset.accept === "true"); data = await fantasyApi.get(); toast.show("Oferta Fantasy", "Respuesta registrada.", "lime"); draw(); } catch (error) { toast.show("Fantasy", error.message, "red"); }
    }));
    const seller = container.querySelector("#fantasySeller");
    seller?.addEventListener("change", () => {
      const manager = data.managers.find((item) => item.id === seller.value);
      const target = container.querySelector("#fantasyTarget");
      if (target) target.innerHTML = (manager?.roster || []).map((entry) => { const player = playerMap.get(entry.playerId); return player && player.available !== false ? `<option value="${player.id}">${safe(player.name)} (${safe(player.position)})</option>` : ""; }).join("");
    });
  }

  load();
  container.__fantasyTimer = window.setInterval(() => {
    if (container.dataset.viewRoute !== "fantasy") {
      window.clearInterval(container.__fantasyTimer);
      container.__fantasyTimer = null;
      return;
    }
    load();
  }, 15000);
}
